﻿using System;

namespace DasPro
{
    class Program
    {
        private const int V = 2;
        private const int V1 = 1;
        private static int jumlahKode;
        private static int hasilTambah;
        private static int hasilKali;
        private static int kodeC;

        //Main Method
        static void Main(string[] args)
            {                
                //Variabel
                //const int a = 5;
                //const int b = 4;
                //const int c = 7;

                //int tambah = a+b+c;
                //int kali = a*b*c;
                //int bagi = a/b/c;


                //Dekrlarasi Variabel
                int kodeA;
                int kodeB;
                int kodeC;
                int jumlahKode;
                String tebakanA;
                String tebakanB;
                String tebakanC;

                int hasilTambah;
                int hasilKali;

                //Inisialisasi Variabel
                kodeA = 1;
                kodeB = 2;
                kodeC = 3;

                jumlahKode = 3;

                //Operasi Aritmatika
                hasilTambah = kodeA+kodeB+kodeC;
                hasilKali = kodeA*kodeB*kodeC;

                //Intro
                Console.WriteLine("Anda adalah agen rahasia yang bertugas mendapatkan data dari server rahasia...");
                Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui..");
                Console.WriteLine("Pasword terdiri dari "+jumlahKode+" angka");
                Console.WriteLine("Jika Ditambahkan hasilnya "+hasilTambah);
                Console.WriteLine("Jika Dikalikan hasilnya "+hasilKali);

                //Input User
                Console.Write("Masukkan Kode 1 : ");
                tebakanA = Console.ReadLine();
                Console.Write("Masukkan Kode 2 : ");
                tebakanB = Console.ReadLine();
                Console.Write("Masukkan kode 3 : ");
                tebakanC = Console.ReadLine();

                Console.WriteLine("Tebakan Anda : "+tebakanA+" "+tebakanB+" "+tebakanC+" ?");

                if(tebakanA == kodeA.ToString() && tebakanB == kodeB.ToString() && tebakanC == kodeC.ToString())
                {
                    Console.WriteLine("Tebakan anda benar!");
                }else{
                    Console.WriteLine("Tebakan anda salah!");
                }
            
            
                //Console.WriteLine("Kode ini jika ditambah " + tambah);
            }
    }
}
