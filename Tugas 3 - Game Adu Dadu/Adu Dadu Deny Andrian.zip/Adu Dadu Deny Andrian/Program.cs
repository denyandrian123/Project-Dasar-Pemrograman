﻿//by Deny Andrian, NIM : 2207111398
using System;

namespace AduDadu
{
    class Program
    {
        static int DaduAnda;
        static int DaduKomputer;
        static int SkorAnda;
        static int SkorKomputer;
        static int SkorSeri;
        static int Ronde = 1;
        static bool GameStart;

        static void Main(string[] args)
        {
            Console.Clear();

            GameStart = true;
            while (GameStart)
            {
               if (Ronde <= 10)
               {
                    if(Ronde == 1)
                    {
                        Intro();
                    }
                    PlayGame();
               }
               else if (Ronde == 10)
               {
                    ShowEnd(false);
                    GameStart = (false);
               }
               else
               {
                    ShowEnd(true);
                    GameStart = (false);
               }
            }
            Console.WriteLine("\nTekan enter untuk keluar");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Makasii yaa udah mau main game ini!");
            Console.WriteLine("Created by:");
            Console.WriteLine("Nama : Deny Andrian");
            Console.WriteLine("NIM : 2207111398");
            Console.WriteLine("Kelas : Teknik Informatika - A");
        }

        static void Int()
        {
            Random Dadu = new Random();
            DaduKomputer = Dadu.Next(1, 7);
            DaduAnda = Dadu.Next(1, 7);
        }

        static void Intro()
        {
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("Pada  game  ini  anda  dan  komputer  akan  bermain  10  ronde");
            Console.WriteLine("Setiap  putaran dadu akan dilempar dan menghasilkan nilai tertentu");
            Console.WriteLine("Nilai  dadu  tertinggi akan  menjadi  pemenang  ronde tersebut");
            Console.WriteLine("Siapakah yang  akan  menang? Selamat  bermain!");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("\nTekan Enter untuk mulai bermain...");
            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
        }

        static void PlayGame()
        {
            Int();
            System.Threading.Thread.Sleep(500);
            Console.WriteLine($"\n\n=========================[ Ronde {Ronde} ]==========================");
            Console.WriteLine("Komputer melempar dadu...");
            Console.Write("...");
            System.Threading.Thread.Sleep(1000);
            Console.Write("\b\b\b\b");
            Console.WriteLine($"- Nilai Komputer : {DaduKomputer}");
            Console.WriteLine("Silahkan lempar dadu anda...");
            Console.ReadKey();
            Console.Write("...");
            System.Threading.Thread.Sleep(1000);
            Console.Write("\b\b\b\b");
            Console.WriteLine($"- Nilai Anda     : {DaduAnda}");

            if (DaduAnda > DaduKomputer)
            {
                SkorAnda++;
                Console.WriteLine("Anda memenangkan ronde ini!");
                Console.WriteLine($"Skor => Anda : {SkorAnda}          Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                if (Ronde < 10)
                {
                    Console.WriteLine("Tekan Enter untuk melanjutkan ke ronde berikutnya...");
                }
                else if (Ronde == 10)
                {
                    Console.WriteLine("Tekan Enter untuk melihat skor akhir...");
                }
                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                Ronde++;
            }
            else if (DaduAnda < DaduKomputer)
            {
                SkorKomputer++;
                Console.WriteLine("Komputer memenangkan ronde ini!");
                Console.WriteLine($"Skor => Anda : {SkorAnda}          Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                if (Ronde < 10)
                {
                    Console.WriteLine("Tekan Enter untuk melanjutkan ke ronde berikutnya...");
                }
                else if (Ronde == 10)
                {
                    Console.WriteLine("Tekan Enter untuk melihat skor akhir...");
                }
                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                Ronde++;
            }
            else
            {
                SkorSeri++;
                Console.WriteLine("Ronde ini seri!");
                Console.WriteLine($"Skor => Anda : {SkorAnda}          Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                if (Ronde < 10)
                {
                    Console.WriteLine("Tekan Enter untuk melanjutkan ke ronde berikutnya...");
                }
                else if (Ronde == 10)
                {
                    Console.WriteLine("Tekan Enter untuk melihat skor akhir...");
                }
                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                Ronde++;
            }
        }

        static void ShowEnd(bool b)
        {
            if (SkorAnda > SkorKomputer)
            {
                Console.WriteLine("\nPermainan selesai!");
                Console.WriteLine($"Skor Akhir => Anda : {SkorAnda}     Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                Console.WriteLine("Selamat! Anda menang! Yey!");
            }
            else if (SkorAnda < SkorKomputer)
            {
                Console.WriteLine("\nPermainan selesai");
                Console.WriteLine($"Skor Akhir => Anda : {SkorAnda}    Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                Console.WriteLine("Yah Sayang sekali Anda kalah... Dicoba lagi ya!");
            }
            else
            {
                Console.WriteLine("\nPermainan selesai");
                Console.WriteLine($"Skor Akhir => Anda : {SkorAnda}    Komputer : {SkorKomputer}          Seri : {SkorSeri}");
                Console.WriteLine("Wihh permainan ini seri!");
            }
        }
    }
}

