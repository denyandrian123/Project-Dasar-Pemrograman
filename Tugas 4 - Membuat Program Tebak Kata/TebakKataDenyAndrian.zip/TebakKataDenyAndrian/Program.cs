﻿using System;
using System.Collections.Generic;

namespace GameTebakKata
{
    class Program
    {
        static int kesempatan = 5;
        static string KataRahasia = "dasar pemrograman";
        static List<string> ListTebakan = new List<String>{};

        static void Main(string[] args)
        {
            Intro();
            MulaiMain();
            EndGame();
        }

        static void Intro()
        {
            Console.WriteLine("=======================================================================");
            Console.WriteLine("Selamat datang, hari ini kita akan bermain tebak kata");
            Console.WriteLine($"Kamu punya {kesempatan} kesempatan untuk menebak kata misteri hari ini");
            Console.WriteLine("Petunjuknya adalah kata ini merupakan mata kuliah yang menyenangkan");
            Console.WriteLine($"Kata tersebut terdiri dari {KataRahasia.Length} karakter.");
            Console.WriteLine("Mata kuliah apakah yang dimaksud?");
            Console.WriteLine("=======================================================================");
            Console.WriteLine("\nTekan Enter untuk mulai bermain..");
            Console.ReadKey();
        }

        static void MulaiMain()
        {
            while (kesempatan>0)
            {
                Console.Write("\nApa karakter tebakanmu? (a-z) :");
                string input = Console.ReadLine();
                ListTebakan.Add(input);
                
                if(CekJawaban(KataRahasia, ListTebakan))
            {
                Console.WriteLine("Selamat kamu berhasil menebaknya!");
                Console.WriteLine($"Kata misterinya {KataRahasia}");
                break;
            }
            else if(KataRahasia.Contains(input))
            {
                Console.WriteLine("Hebat! Kamu berhasil menebaknya!");
                Console.WriteLine(CekHuruf(KataRahasia, ListTebakan));
            }else
            {
                Console.WriteLine("Sayang sekali tebakan kamu salah!");
                kesempatan--;
                Console.WriteLine($"Sisa {kesempatan} kesempatan");
            }

            }
        }

        static bool CekJawaban(string KataRahasia, List<string> list)
    {
        bool status = false;
        for (int i = 0 ; i < KataRahasia.Length; i++)
        {
            string c = Convert.ToString(KataRahasia[i]);
            if(list.Contains(c)){
                status = true;
            }else{
                return status = false;
            }
        }

        return status;
    }

        static string CekHuruf(string KataRahasia, List<string> list)
        {
            string x = "";

            for (int i=0; i < KataRahasia.Length; i++)
            {
                string c = Convert.ToString(KataRahasia[i]);
                if(list.Contains(c))
                {
                    x = x + c;
                }else
                {
                    x = x + "-";
                }
            }

            return x;
        }
        static void EndGame()
        {
            Console.WriteLine("\nKesempatan Telah Habis...");
            Console.WriteLine("Permainan Berakhir");
        }

    }
}




